﻿using System.Collections.Concurrent;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<MessageRateLimiter>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularUI", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Enable CORS
app.UseCors("AllowAngularUI");

app.UseRouting();

app.UseEndpoints((Action<IEndpointRouteBuilder>)(endpoints =>
{
    // ✅ API: Check if an SMS can be sent
    endpoints.MapPost("/api/sms/can-send", (SmsRequest request, MessageRateLimiter rateLimiter) =>
    {
        if (request == null || string.IsNullOrEmpty(request.PhoneNumber))
        {
            return Results.BadRequest("Invalid request payload.");
        }

        bool canSend = rateLimiter.CanSendSms(request.PhoneNumber);
        return Results.Json(new { canSend, reason = canSend ? "Allowed" : "Limit Exceeded" });
    });

    // ✅ API: Monitor current SMS usage
    endpoints.MapGet("/api/sms/monitor", (MessageRateLimiter rateLimiter) =>
    {
        return Results.Json(rateLimiter.GetCurrentUsage());
    });

    // ✅ API: Reset rate limits (Admin Key required)
    endpoints.MapPost("/api/sms/reset", (MessageRateLimiter rateLimiter) =>
    {
        rateLimiter.ResetLimits();
        return Results.Json(new { message = "Limits reset successfully" });
    });
}));

app.Run();

/// ✅ Request model for sending an SMS
public record SmsRequest(string PhoneNumber);

/// ✅ Request model for resetting limits (requires admin key)
public record ResetRequest(string AdminKey);

/// ✅ SMS Rate Limiter Class
public class MessageRateLimiter
{
    private readonly int _maxPerNumber = 5;
    private readonly int _maxPerAccount = 50;
    private readonly ConcurrentDictionary<string, ConcurrentQueue<DateTime>> _phoneNumberRequests = new();
    private readonly ConcurrentQueue<DateTime> _accountRequests = new();
    private readonly object _lock = new();

    public bool CanSendSms(string phoneNumber)
    {
        lock (_lock)
        {
            var now = DateTime.UtcNow;
            CleanupOldRequests(now);

            if (_accountRequests.Count >= _maxPerAccount)
                return false;

            var queue = _phoneNumberRequests.GetOrAdd(phoneNumber, _ => new ConcurrentQueue<DateTime>());
            if (queue.Count >= _maxPerNumber)
                return false;

            queue.Enqueue(now);
            _accountRequests.Enqueue(now);
            return true;
        }
    }

    public object GetCurrentUsage()
    {
        lock (_lock)
        {
            return new
            {
                PerNumber = _phoneNumberRequests
                    .Where(kvp => kvp.Value.Count > 0)
                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value.Count),

                TotalAccountMessages = _accountRequests.Count
            };
        }
    }

    public void ResetLimits()
    {
        lock (_lock)
        {
            // ✅ Reset per-number limits
            _phoneNumberRequests.Clear();

            // ✅ Reset total account messages
            while (_accountRequests.TryDequeue(out _)) { }
        }
    }

    private void CleanupOldRequests(DateTime now)
    {
        lock (_lock)
        {
            foreach (var key in _phoneNumberRequests.Keys)
            {
                if (_phoneNumberRequests.TryGetValue(key, out var queue))
                {
                    while (queue.TryPeek(out var timestamp) && (now - timestamp).TotalSeconds >= 60)
                    {
                        queue.TryDequeue(out _);
                    }

                    if (queue.IsEmpty)
                    {
                        _phoneNumberRequests.TryRemove(key, out _);
                    }
                }
            }

            while (_accountRequests.TryPeek(out var timestamp) && (now - timestamp).TotalSeconds >= 60)
            {
                _accountRequests.TryDequeue(out _);
            }
        }
    }
}
