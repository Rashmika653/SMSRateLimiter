﻿using System;
using System.Collections.Concurrent;

namespace SmsRateLimiter
{
	public class test
	{
        /*
		using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;

var builder = WebApplication.CreateBuilder(args);


    builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<SmsRateLimiter>();
var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseRouting();

app.UseEndpoints(endpoints =>
{
    endpoints.MapPost("/api/sms/can-send", async (HttpContext context, SmsRateLimiter rateLimiter) =>
    {
        var request = await context.Request.ReadFromJsonAsync<SmsRequest>();
        if (request == null || string.IsNullOrEmpty(request.PhoneNumber))
        {
            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            await context.Response.WriteAsync("Invalid request.");
            return;
        }

        bool canSend = rateLimiter.CanSendSms(request.PhoneNumber);
        await context.Response.WriteAsJsonAsync(new { canSend, reason = canSend ? "Allowed" : "Limit Exceeded" });
    });

    endpoints.MapGet("/api/sms/monitor", (SmsRateLimiter rateLimiter) =>
    {
        return Results.Json(rateLimiter.GetCurrentUsage());
    });

    endpoints.MapPost("/api/sms/reset", (SmsRateLimiter rateLimiter) =>
    {
        rateLimiter.ResetLimits();
        return Results.Json(new { message = "Limits reset successfully" });
    });
});

app.Run();

public record SmsRequest(string PhoneNumber);

public class SmsRateLimiter
{
    private readonly int _maxPerNumber = 5;
    private readonly int _maxPerAccount = 50;
    private readonly ConcurrentDictionary<string, ConcurrentQueue<DateTime>> _phoneNumberRequests = new();
    private readonly ConcurrentQueue<DateTime> _accountRequests = new();
    private readonly object _lock = new();

    public bool CanSendSms(string phoneNumber)
    {
        lock (_lock)
        {
            var now = DateTime.UtcNow;
            CleanupOldRequests(now);

            if (_accountRequests.Count >= _maxPerAccount)
                return false;

            var queue = _phoneNumberRequests.GetOrAdd(phoneNumber, _ => new ConcurrentQueue<DateTime>());
            if (queue.Count >= _maxPerNumber)
                return false;

            queue.Enqueue(now);
            _accountRequests.Enqueue(now);
            return true;
        }
    }

    public object GetCurrentUsage()
    {
        return new
        {
            PerNumber = _phoneNumberRequests.ToDictionary(kvp => kvp.Key, kvp => kvp.Value.Count),
            TotalAccountMessages = _accountRequests.Count
        };
    }

    public void ResetLimits()
    {
        _phoneNumberRequests.Clear();
        while (_accountRequests.TryDequeue(out _)) { }
    }

    private void CleanupOldRequests(DateTime now)
    {
        foreach (var key in _phoneNumberRequests.Keys)
        {
            while (_phoneNumberRequests[key].TryPeek(out var timestamp) && (now - timestamp).TotalSeconds >= 1)
            {
                _phoneNumberRequests[key].TryDequeue(out _);
            }
        }

        while (_accountRequests.TryPeek(out var timestamp) && (now - timestamp).TotalSeconds >= 1)
        {
            _accountRequests.TryDequeue(out _);
        }
    }
}
*/

//var builder = WebApplication.CreateBuilder(args);

//// Add Swagger services
//builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

//var app = builder.Build();

//// Enable Swagger
//if (app.Environment.IsDevelopment())
//{
//    app.UseSwagger();
//    app.UseSwaggerUI();
//}

//app.MapPost("/api/products", async (Product product) =>
//{
//    return Results.Created($"/api/products/{product.Id}", product);
//});

//app.Run();

//record Product(int Id, string Name, decimal Price);


	}
}

