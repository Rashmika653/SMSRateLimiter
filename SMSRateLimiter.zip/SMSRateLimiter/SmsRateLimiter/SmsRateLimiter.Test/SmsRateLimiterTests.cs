﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Text.Json;
using Xunit;

public class SmsRateLimiterTests
{
    private readonly MessageRateLimiter _rateLimiter;

    public SmsRateLimiterTests()
    {
        _rateLimiter = new MessageRateLimiter();
    }

    [Fact]
    public void CanSendSms_ShouldAllow_WhenLimitNotReached()
    {
        var phoneNumber = "+1234567890";

        for (int i = 0; i < 5; i++)
        {
            bool canSend = _rateLimiter.CanSendSms(phoneNumber);
            Assert.True(canSend, $"SMS {i + 1} should be allowed.");
        }
    }

    [Fact]
    public void CanSendSms_ShouldBlock_WhenPerNumberLimitExceeded()
    {
        var phoneNumber = "+1234567890";

        for (int i = 0; i < 5; i++)
        {
            _rateLimiter.CanSendSms(phoneNumber);
        }

        bool canSend = _rateLimiter.CanSendSms(phoneNumber);
        Assert.False(canSend, "6th SMS should be blocked.");
    }

    [Fact]
    public void GetCurrentUsage_ShouldReturnCorrectValues()
    {
        _rateLimiter.CanSendSms("+1234567890");
        _rateLimiter.CanSendSms("+1234567891");

        var usage = _rateLimiter.GetCurrentUsage();
        var usageJson = JsonSerializer.Serialize(usage);
        var usageData = JsonSerializer.Deserialize<UsageData>(usageJson);

        Assert.NotNull(usageData);
        Assert.Equal(1, usageData.PerNumber["+1234567890"]);
        Assert.Equal(1, usageData.PerNumber["+1234567891"]);
        Assert.Equal(2, usageData.TotalAccountMessages);
    }

    [Fact]
    public void ResetLimits_ShouldClearAllLimits()
    {
        _rateLimiter.CanSendSms("+1234567890");
        _rateLimiter.ResetLimits();

        var usage = _rateLimiter.GetCurrentUsage();
        var usageJson = JsonSerializer.Serialize(usage);
        var usageData = JsonSerializer.Deserialize<UsageData>(usageJson);

        Assert.NotNull(usageData);
        Assert.Empty(usageData.PerNumber);
        Assert.Equal(0, usageData.TotalAccountMessages);
    }
}

/// ✅ Strongly typed class for deserialization
public class UsageData
{
    public Dictionary<string, int> PerNumber { get; set; } = new();
    public int TotalAccountMessages { get; set; }
}
