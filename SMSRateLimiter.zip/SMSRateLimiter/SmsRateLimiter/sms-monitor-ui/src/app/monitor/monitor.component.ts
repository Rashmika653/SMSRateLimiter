import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';

@Component({
  selector: 'app-monitor',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatCardModule, MatListModule],
  templateUrl: './monitor.component.html',
  styleUrl: './monitor.component.css'
})
export class MonitorComponent  implements OnInit {
  rateLimits: any;
  apiUrl = 'https://localhost:5001/api/sms';

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.fetchRateLimits();
    setInterval(() => this.fetchRateLimits(), 5000);
  }

  fetchRateLimits() {
    this.http.get(`${this.apiUrl}/monitor`).subscribe(data => {
      this.rateLimits = data;
    });
  }

  resetLimits() {
    this.http.post(`${this.apiUrl}/reset`, {}).subscribe(() => {
      alert('Rate limits reset!');
      this.fetchRateLimits();
    });
  }
}